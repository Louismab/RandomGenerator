#include "pch.h"
#include "UniformGenerator.h"


UniformGenerator::UniformGenerator()
{
}