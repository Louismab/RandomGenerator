#pragma once
#include "RandomGenerator.h"


class UniformGenerator : public RandomGenerator
{
public:
	UniformGenerator();

};

